//
//  ViewController.swift
//  Proyecto
//
//  Created by Gustavin on 13/04/18.
//  Copyright © 2018 moviles. All rights reserved.
//

import UIKit

let emailTextField: UITextField = {
   let e = UITextField()
    e.placeholder = "Email"
    e.textColor = .white
    e.backgroundColor = .red
    e.textColor = .white
    e.isSecureTextEntry = true
    return e
}()
let passwordTextField: UITextField = {
    let p = UITextField()
        p.placeholder = "Password"
        p.textColor = .white
        p.backgroundColor = .blue
    return p
}()

let loginButton: UIButton = {
    let l = UIButton(type: .system)
        l.setTitleColor(.white, for: .normal)
        l.setTitle("Log In", for: .normal)
        l.backgroundColor = .purple
    
    return l
}()

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        view.backgroundColor = THEME
        
        setupTextFielComponents()
        
        setupLoginButton()
    }
    
    fileprivate func setupTextFielComponents (){
        setupEmailField()
        setupPasswordField()
        
    }
    
    fileprivate func setupEmailField (){
        view.addSubview(emailTextField)
        emailTextField.translatesAutoresizingMaskIntoConstraints = false
        emailTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16).isActive = true
        emailTextField.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 24).isActive = true
        emailTextField.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -24).isActive = true
        emailTextField.heightAnchor.constraint(equalToConstant: 30).isActive = true
    }
    
    fileprivate func setupPasswordField(){
        view.addSubview(passwordTextField)
        
        passwordTextField.translatesAutoresizingMaskIntoConstraints = false
        passwordTextField.topAnchor.constraint(equalTo: emailTextField.bottomAnchor, constant: 8).isActive = true
        passwordTextField.leftAnchor.constraint(equalTo: emailTextField.leftAnchor, constant: 0).isActive = true
        passwordTextField.rightAnchor.constraint(equalTo: emailTextField.rightAnchor, constant: 0).isActive = true
        passwordTextField.heightAnchor.constraint(equalToConstant: 30).isActive = true
    }
    
    fileprivate func setupLoginButton (){
        view.addSubview(loginButton)
        
        loginButton.translatesAutoresizingMaskIntoConstraints = false
        loginButton.topAnchor.constraint(equalTo: passwordTextField.bottomAnchor, constant: 8).isActive = true
        loginButton.leftAnchor.constraintEqualToSystemSpacingAfter(passwordTextField.leftAnchor, multiplier: 0).isActive = true
        loginButton.rightAnchor.constraintEqualToSystemSpacingAfter(passwordTextField.rightAnchor, multiplier: 0).isActive = true
        loginButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
    
    
}
