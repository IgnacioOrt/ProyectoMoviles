//
//  CommentController.swift
//  Proyecto
//
//  Created by Gustavin on 15/04/18.
//  Copyright © 2018 moviles. All rights reserved.
//

import UIKit

class commentController: UIViewController, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {
    
    let container: UICollectionView = {
       let c = UICollectionViewFlowLayout()
        c.minimumLineSpacing = 5
        c.scrollDirection = .vertical
        let cv = UICollectionView(frame: .zero, collectionViewLayout: c)
        cv.backgroundColor = .clear
        return cv
    }()
    
    let imagesCellId = "imagesCellId"
    let albumsCellId = "albumsCellId"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.white
        navigationController?.navigationBar.prefersLargeTitles = true
        
        navigationItem.title = "Ultimos comentarios"
        setupContainer()
    }
    
    fileprivate func setupContainer(){
        container.delegate = self
        container.dataSource = self
        
        view.addSubview(container)
        container.anchors(top: view.topAnchor, topPad: 0, bottom: view.bottomAnchor, bottomPad: 0, left: view.leftAnchor, leftPad: 0, right: view.rightAnchor, rightPad: 0, height: 0, width: 0)
        
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 1{
            return 9
        }
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: imagesCellId, for: indexPath)
            return cell
        }
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: albumsCellId, for: indexPath)
    }
    
}

cla
