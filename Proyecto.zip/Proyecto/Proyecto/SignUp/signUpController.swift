//
//  signUp.swift
//  Proyecto
//
//  Created by Gustavin on 14/04/18.
//  Copyright © 2018 moviles. All rights reserved.
//

import UIKit

class signUpController: UIViewController {
    let coolPlacesLabel: UILabel = {
        let l = UILabel()
        l.text = "Cool Places"
        l.textAlignment = .center
        l.font = UIFont(name: "CoconutPunchDEMO-Regular", size: 35)
        return l
    }()
    let nameField: UITextField = {
        let nf = UITextField()
        nf.backgroundColor = .purple
        let attributedPlaceholder = NSAttributedString(string: "Nombre", attributes:
            [NSAttributedStringKey.foregroundColor : UIColor.white])
        nf.textColor = .white
        nf.attributedPlaceholder = attributedPlaceholder
        
        
        return nf
    }()
    let userField: UITextField = {
        let n = UITextField()
        n.placeholder = "Nombre de usuario"
        n.textColor = .white
        n.backgroundColor = .purple
        n.textColor = .white
        return n
    }()
    let passwordField: UITextField = {
        let p = UITextField()
            p.placeholder = "Contraseña"
            p.textColor = .white
            p.backgroundColor = .purple
            p.textColor = .white
            p.isSecureTextEntry = true

        return p
    }()
    let confirmPasswordField: UITextField = {
        let p = UITextField()
        p.placeholder = "Confirmar contraseña"
        p.textColor = .white
        p.backgroundColor = .purple
        p.textColor = .white
        p.isSecureTextEntry = true
        return p
    }()
    let signUpButton: UIButton = {
        let s = UIButton(type: .system)
        s.setTitle("Registrarse", for: .normal)
        s.backgroundColor = .purple
        s.addTarget(self, action: #selector(signUpAction), for: .touchUpInside)
        return s
    }()
    
    let backButton: UIButton = {
        let color = UIColor.rgb(r: 89, g: 156, b: 120)
        let font = UIFont.systemFont(ofSize: 16)
        
        let h = UIButton(type: .system)
        
        let attributedTitle = NSMutableAttributedString(string:
            "", attributes: [NSAttributedStringKey.foregroundColor:
                color, NSAttributedStringKey.font : font ])
        
        attributedTitle.append(NSAttributedString(string: "Regresar", attributes:
            [NSAttributedStringKey.foregroundColor: UIColor.purple,
             NSAttributedStringKey.font: font]))
        
        h.addTarget(self, action: #selector(backAction), for: .touchUpInside)
        h.setAttributedTitle(attributedTitle, for: .normal)
        return h
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = THEME

        navigationController?.isNavigationBarHidden = true

        setupCoolPlacesText()
        setupNameField()
        setupUserField()
        setupPasswordField()
        setupConfirmPasswordField()
        setupSignUpButton()
        setupBackButton()
    }
    
    fileprivate func setupCoolPlacesText (){
        view.addSubview(coolPlacesLabel)
        coolPlacesLabel.anchors(top: view.safeAreaLayoutGuide.topAnchor, topPad: 50, bottom: nil, bottomPad: 0, left: view.leftAnchor, leftPad: 24, right: view.rightAnchor, rightPad: 24, height: 30, width: 0)
    }
    
    fileprivate func setupNameField(){
        view.addSubview(nameField)
        nameField.anchors(top: nil, topPad: 0, bottom: nil, bottomPad: 0,
                               left: view.leftAnchor, leftPad: 24, right: view.rightAnchor,
                               rightPad: 24, height: 30, width: 0)
        nameField.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        
    }
 
    fileprivate func setupUserField() {
        view.addSubview(userField)
        userField.anchors(top: nameField.bottomAnchor, topPad: 8, bottom: nil, bottomPad: 0, left: nameField.leftAnchor, leftPad: 0, right: nameField.rightAnchor, rightPad: 0, height: 30, width: 0)
    }
    
    fileprivate func setupPasswordField (){
        view.addSubview(passwordField)
        passwordField.anchors(top: userField.bottomAnchor, topPad: 8, bottom: nil, bottomPad: 0, left: userField.leftAnchor, leftPad: 0, right: userField.rightAnchor, rightPad: 0, height: 30, width: 0)
    }
    
    fileprivate func setupConfirmPasswordField (){
        view.addSubview(confirmPasswordField)
        confirmPasswordField.anchors(top: passwordField.bottomAnchor, topPad: 8, bottom: nil, bottomPad: 0, left: passwordField.leftAnchor, leftPad: 0, right: passwordField.rightAnchor, rightPad: 0, height: 30, width: 0)
    }
    fileprivate func setupSignUpButton (){
        view.addSubview(signUpButton)
        signUpButton.anchors(top: confirmPasswordField.bottomAnchor, topPad: 8, bottom: nil, bottomPad: 0, left: confirmPasswordField.leftAnchor, leftPad: 0, right: confirmPasswordField.rightAnchor, rightPad: 0, height: 30, width: 0)
    }
    
    fileprivate func setupBackButton (){
        view.addSubview(backButton)
        backButton.anchors(top: signUpButton.bottomAnchor, topPad: 8, bottom: nil, bottomPad: 0, left: signUpButton.leftAnchor, leftPad: 0, right: signUpButton.rightAnchor, rightPad: 0, height: 30, width: 0)
    }
    
    @objc func signUpAction (){
        print("Registrado")
    }
    
    @objc func backAction (){
        navigationController?.popViewController(animated: true)
    }
}
