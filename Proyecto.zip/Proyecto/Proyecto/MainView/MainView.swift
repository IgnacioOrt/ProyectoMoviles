//
//  ViewController.swift
//  Proyecto
//
//  Created by Gustavin on 13/04/18.
//  Copyright © 2018 moviles. All rights reserved.
//

import UIKit

class MainView: UIViewController {
    
    //Titulo Cool Places
    let coolPlacesLabel: UILabel = {
        let l = UILabel()
        l.text = "Cool Places"
        l.textAlignment = .center
        l.font = UIFont(name: "CoconutPunchDEMO-Regular", size: 35)
        return l
    }()
    //Login Button
    let loginButton: UIButton = {
        let l = UIButton(type: .system)
        l.setTitleColor(.white, for: .normal)
        l.setTitle("Log In", for: .normal)
        l.backgroundColor = .purple
        l.addTarget(self, action: #selector(loginAction), for: .touchUpInside)
        return l
    }()
    //Sign Up Button
    
    let signUpButton: UIButton = {
        let s = UIButton(type: .system)
        s.setTitleColor(.white, for: .normal)
        s.setTitle("Sign Up", for: .normal)
        s.backgroundColor = GREEN_BUTTON
        s.addTarget(self, action: #selector(signUpAction), for: .touchUpInside)
        return s
    }()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        view.backgroundColor = THEME
        
        navigationController?.isNavigationBarHidden = true
        
        setupCoolPlacesText()
        setupLoginButton()
        setupSignUpButton()
    }
    
    fileprivate func setupSignUpButton (){
        view.addSubview(signUpButton)
        signUpButton.translatesAutoresizingMaskIntoConstraints = false
        signUpButton.topAnchor.constraint(equalTo: loginButton.bottomAnchor, constant: 8).isActive = true
        signUpButton.leftAnchor.constraint(equalTo: loginButton.leftAnchor, constant: 0).isActive = true
        signUpButton.rightAnchor.constraint(equalTo: loginButton.rightAnchor, constant: 0).isActive = true
        signUpButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
    
    
    
    fileprivate func setupLoginButton (){
        view.addSubview(loginButton)
        
        loginButton.translatesAutoresizingMaskIntoConstraints = false
        loginButton.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 24).isActive = true
        loginButton.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -24).isActive = true
        loginButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        loginButton.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
 }
    @objc func loginAction (){
        let logController = loginController()
        navigationController?.pushViewController(logController, animated: true)
    }
    
    @objc func signUpAction (){
        let signController = signUpController()
        navigationController?.pushViewController(signController, animated: true)
    }
    
    fileprivate func setupCoolPlacesText (){
        view.addSubview(coolPlacesLabel)
        coolPlacesLabel.translatesAutoresizingMaskIntoConstraints = false
        coolPlacesLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50).isActive = true
        coolPlacesLabel.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 24).isActive = true
        coolPlacesLabel.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -24).isActive = true
        coolPlacesLabel.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
    }
}
