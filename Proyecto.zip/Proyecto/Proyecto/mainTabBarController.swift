//
//  MainTabBarController.swift
//  Proyecto
//
//  Created by Gustavin on 15/04/18.
//  Copyright © 2018 moviles. All rights reserved.
//

import UIKit


class mainTabBarController: UITabBarController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabBar.barTintColor = UIColor.rgb(r: 38, g: 196, b: 133)
        setupTabBar()
    }
    
    func setupTabBar() {
        let comController = commentController()
        comController.tabBarItem.image = UIImage(named: "comment-black")
        comController.tabBarItem.selectedImage = UIImage(named: "comment-white")
        
        let addComController = addCommentController()
        addComController.tabBarItem.image = UIImage(named: "comment-black")
        addComController.tabBarItem.selectedImage = UIImage(named: "comment-white")
        
        viewControllers = [comController, addComController]
    }
    
}
