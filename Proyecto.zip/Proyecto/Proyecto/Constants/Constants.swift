//
//  Constants.swift
//  Proyecto
//
//  Created by Gustavin on 13/04/18.
//  Copyright © 2018 moviles. All rights reserved.
//

import Foundation
import UIKit

let THEME = UIColor (displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
let GREEN_BUTTON = UIColor.rgb(r: 38, g: 196, b: 133)
