//
//  profileController.swift
//  Proyecto
//
//  Created by Gustavin on 15/04/18.
//  Copyright © 2018 moviles. All rights reserved.
//

import UIKit

class profileController: UINavigationController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

