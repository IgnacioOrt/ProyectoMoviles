//
//  AddCommentController.swift
//  Proyecto
//
//  Created by Gustavin on 15/04/18.
//  Copyright © 2018 moviles. All rights reserved.
//

import UIKit

class addCommentController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.title = "Añadir comentario"
    }
}
