//
//  LoginController.swift
//  Proyecto
//
//  Created by Gustavin on 14/04/18.
//  Copyright © 2018 moviles. All rights reserved.
//

import UIKit

class loginController: UIViewController {
    
    let coolPlacesLabel: UILabel = {
        let l = UILabel()
        l.text = "Cool Places"
        l.textAlignment = .center
        l.font = UIFont(name: "CoconutPunchDEMO-Regular", size: 35)
        return l
    }()
    
    //Login Button
    let loginButton: UIButton = {
        let l = UIButton(type: .system)
        l.setTitleColor(.white, for: .normal)
        l.setTitle("Log In", for: .normal)
        l.backgroundColor = .purple
        l.addTarget(self, action: #selector(loginAction), for: .touchUpInside)
        return l
    }()
    
    let backButton: UIButton = {
        let color = UIColor.rgb(r: 89, g: 156, b: 120)
        let font = UIFont.systemFont(ofSize: 16)
        
        let h = UIButton(type: .system)
        
        let attributedTitle = NSMutableAttributedString(string:
            "", attributes: [NSAttributedStringKey.foregroundColor:
                color, NSAttributedStringKey.font : font ])
        
        attributedTitle.append(NSAttributedString(string: "Regresar", attributes:
            [NSAttributedStringKey.foregroundColor: UIColor.purple,
             NSAttributedStringKey.font: font]))
        
        h.addTarget(self, action: #selector(backAction), for: .touchUpInside)
        h.setAttributedTitle(attributedTitle, for: .normal)
        return h
    }()
    
    let userTextField: UITextField = {
        let e = UITextField()
        e.placeholder = "Nombre de usuario"
        e.textColor = .white
        e.backgroundColor = .red
        e.textColor = .white
        return e
    }()
    let passwordTextField: UITextField = {
        let p = UITextField()
        p.placeholder = "Contraseña"
        p.isSecureTextEntry = true
        p.textColor = .white
        p.backgroundColor = .blue
        return p
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = THEME

        //navigationController?.isNavigationBarHidden = false
        setupCoolPlacesText()
        setupUserTextField()
        setupPasswordTextField()
        
        setupLoginButton()
        setupBackButton()
    }
    
    fileprivate func setupCoolPlacesText (){
        view.addSubview(coolPlacesLabel)
        coolPlacesLabel.translatesAutoresizingMaskIntoConstraints = false
        coolPlacesLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50).isActive = true
        coolPlacesLabel.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 24).isActive = true
        coolPlacesLabel.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -24).isActive = true
        coolPlacesLabel.heightAnchor.constraint(equalToConstant: 30).isActive = true
    }
    
    fileprivate func setupUserTextField(){
        view.addSubview(userTextField)
        
        userTextField.translatesAutoresizingMaskIntoConstraints = false
        userTextField.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        userTextField.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 24).isActive = true
        userTextField.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -24).isActive = true
        userTextField.heightAnchor.constraint(equalToConstant: 30)
    }
    
    fileprivate func setupPasswordTextField (){
        view.addSubview(passwordTextField)
        
        passwordTextField.translatesAutoresizingMaskIntoConstraints = false
        passwordTextField.topAnchor.constraint(equalTo: userTextField.bottomAnchor, constant: 8).isActive = true
        passwordTextField.leftAnchor.constraint(equalTo: userTextField.leftAnchor, constant: 0).isActive = true
        passwordTextField.rightAnchor.constraint(equalTo: userTextField.rightAnchor, constant: 0).isActive = true
        passwordTextField.heightAnchor.constraint(equalToConstant: 30)
    }
    
    fileprivate func setupLoginButton (){
        view.addSubview(loginButton)
        
        loginButton.translatesAutoresizingMaskIntoConstraints = false
        loginButton.topAnchor.constraint(equalTo: passwordTextField.bottomAnchor, constant: 8).isActive = true
        loginButton.leftAnchor.constraint(equalTo: passwordTextField.leftAnchor, constant: 24).isActive = true
        loginButton.rightAnchor.constraint(equalTo: passwordTextField.rightAnchor, constant: -24).isActive = true
        loginButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
    fileprivate func setupBackButton (){
        view.addSubview(backButton)
        
         backButton.translatesAutoresizingMaskIntoConstraints = false
        backButton.topAnchor.constraint(equalTo: loginButton.bottomAnchor, constant: 8).isActive = true
        backButton.leftAnchor.constraint(equalTo: loginButton.leftAnchor, constant: 0).isActive = true
        backButton.rightAnchor.constraint(equalTo: loginButton.rightAnchor, constant: 0).isActive = true
        backButton.heightAnchor.constraint(equalToConstant: 20)
    }
    
    @objc func loginAction (){
        
        let mainTabBar = mainTabBarController()
        navigationController?.pushViewController(mainTabBar, animated: true)
 
    }
    
    
    @objc func backAction (){
        navigationController?.popViewController(animated: true)
    }
}
